# OpenBIM Core

OpenBIM Core is the dependency-light IFC ingestion boundary shared by CDI and
Genba Lab. It reads IFC into source-faithful records and renderer-neutral
geometry packets. It does not own a viewer, ontology, knowledge system,
simulation, grouping rule or application workflow.

F1 status: the package and conformance boundary are implemented, but neither
consumer has switched to it. Genba migration is F2; CDI's read-only IFC host is
F3. The governing architecture decision is
[`../planning/OPENBIM-CORE-FOUNDATION.md`](../planning/OPENBIM-CORE-FOUNDATION.md).

## Contract

`parseIfc(api, WebIFC, bytes, options)` takes an initialised `web-ifc` API from
the caller and returns `openbim-kernel-result-v1`:

- exact asset and parser provenance;
- source-scoped IFC identity;
- entities including spaces and openings even when they have no geometry;
- complete occurrence and type-inherited property/quantity sets;
- material associations;
- explicit native `IfcRel*` relationships; and
- transferable typed-array geometry packets.

The caller supplies a stable model `bindingId`, project-relative `assetRef` and
exact `sha256:` content digest. Use `sha256Digest(bytes)` before parsing or the
Worker helper, which computes it when omitted.

Current package version: `0.1.1`. The 0.1.1 compatibility addition preserves
IFC `LongName` separately from `Name`, required by Genba's existing project
label behavior; the result schema remains `openbim-kernel-result-v1`.

```js
import * as WebIFC from 'web-ifc'
import { parseIfc, sha256Digest } from '@onuresen/openbim-core'

const api = new WebIFC.IfcAPI()
await api.Init()
const contentDigest = await sha256Digest(bytes)
const result = parseIfc(api, WebIFC, bytes, {
  bindingId: 'main-model',
  assetRef: 'models/building.ifc',
  contentDigest,
})
```

`createIfcWorkerHandler()` owns only the message/transfer protocol. The
consumer still owns API creation and its bundler-specific WASM URL:

```js
const handle = createIfcWorkerHandler({ loadApi, WebIFC })
self.onmessage = async event => {
  const { message, transfer } = await handle(event.data, progress => {
    self.postMessage(progress)
  })
  self.postMessage(message, transfer)
}
```

## Non-negotiable boundaries

- `GlobalId`, exact-file `expressId` and viewer-local render IDs are distinct.
- Missing or duplicate `GlobalId` values use an explicitly file-scoped key and
  emit diagnostics; they are never merged.
- Properties are not truncated.
- No IFC class is skipped because one consumer does not display it.
- Geometry contact, grouping and estimates are consumer projections, never
  source-native IFC facts.
- The package imports no React, Three.js, APS or CDI module.

## Verify

```text
npm test
```

The suite combines a deterministic fake-API conformance model with a small,
redistributable IFC2X3 fixture parsed by real `web-ifc`.
