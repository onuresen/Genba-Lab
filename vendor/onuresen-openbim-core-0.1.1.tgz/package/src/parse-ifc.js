import { isValidIfcGlobalId, sourceKeyFor, validateSource } from './identity.js'

export const OPENBIM_CORE_VERSION = '0.1.1'

const QUANTITY_KEYS = [
  'LengthValue', 'AreaValue', 'VolumeValue', 'CountValue', 'WeightValue',
  'TimeValue', 'NominalValue',
]

const CLASS_NAMES = {
  IFCPROJECT: 'IfcProject', IFCSITE: 'IfcSite', IFCBUILDING: 'IfcBuilding',
  IFCBUILDINGSTOREY: 'IfcBuildingStorey', IFCSPACE: 'IfcSpace',
  IFCOPENINGELEMENT: 'IfcOpeningElement', IFCOPENINGSTANDARDCASE: 'IfcOpeningElement',
  IFCWALL: 'IfcWall', IFCWALLSTANDARDCASE: 'IfcWall', IFCWALLELEMENTEDCASE: 'IfcWall',
  IFCWALLTYPE: 'IfcWallType', IFCSLAB: 'IfcSlab', IFCCOLUMN: 'IfcColumn', IFCBEAM: 'IfcBeam',
  IFCDOOR: 'IfcDoor', IFCWINDOW: 'IfcWindow', IFCROOF: 'IfcRoof', IFCSTAIR: 'IfcStair',
  IFCFOOTING: 'IfcFooting', IFCPILE: 'IfcPile', IFCBUILDINGELEMENTPROXY: 'IfcBuildingElementProxy',
  IFCPROPERTYSET: 'IfcPropertySet', IFCELEMENTQUANTITY: 'IfcElementQuantity',
  IFCRELCONTAINEDINSPATIALSTRUCTURE: 'IfcRelContainedInSpatialStructure',
  IFCRELAGGREGATES: 'IfcRelAggregates', IFCRELNESTS: 'IfcRelNests',
  IFCRELDEFINESBYPROPERTIES: 'IfcRelDefinesByProperties',
  IFCRELDEFINESBYTYPE: 'IfcRelDefinesByType',
  IFCRELASSOCIATESMATERIAL: 'IfcRelAssociatesMaterial',
}

function vectorValues(vector) {
  const out = []
  if (!vector) return out
  for (let index = 0; index < vector.size(); index += 1) out.push(vector.get(index))
  return out
}

function wrappedValue(value) {
  if (value == null) return null
  if (value._representationValue !== undefined) return value._representationValue
  if (value.value !== undefined) return value.value
  return value
}

function text(value) {
  const unwrapped = wrappedValue(value)
  return typeof unwrapped === 'string' ? unwrapped : ''
}

function typeName(api, typeCode) {
  try {
    return String(api.GetNameFromTypeCode(typeCode) || '').toUpperCase()
  } catch {
    return ''
  }
}

export function ifcClassName(name) {
  const upper = String(name || '').toUpperCase()
  if (CLASS_NAMES[upper]) return CLASS_NAMES[upper]
  if (!upper.startsWith('IFC')) return upper || 'IfcUnknown'
  return `Ifc${upper.slice(3).toLowerCase().replace(/(^|_)([a-z])/g, (_all, _gap, letter) => letter.toUpperCase())}`
}

function toHex(colour) {
  const component = value => Math.round(Math.max(0, Math.min(1, Number(value) || 0)) * 255)
    .toString(16).padStart(2, '0')
  return `#${component(colour?.x)}${component(colour?.y)}${component(colour?.z)}`
}

function transformPoint(matrix, x, y, z) {
  return [
    matrix[0] * x + matrix[4] * y + matrix[8] * z + matrix[12],
    matrix[1] * x + matrix[5] * y + matrix[9] * z + matrix[13],
    matrix[2] * x + matrix[6] * y + matrix[10] * z + matrix[14],
  ]
}

function transformNormal(matrix, x, y, z) {
  const a00 = matrix[0], a01 = matrix[4], a02 = matrix[8]
  const a10 = matrix[1], a11 = matrix[5], a12 = matrix[9]
  const a20 = matrix[2], a21 = matrix[6], a22 = matrix[10]
  const tx = (a11 * a22 - a12 * a21) * x + (a12 * a20 - a10 * a22) * y + (a10 * a21 - a11 * a20) * z
  const ty = (a02 * a21 - a01 * a22) * x + (a00 * a22 - a02 * a20) * y + (a01 * a20 - a00 * a21) * z
  const tz = (a01 * a12 - a02 * a11) * x + (a02 * a10 - a00 * a12) * y + (a00 * a11 - a01 * a10) * z
  const length = Math.hypot(tx, ty, tz) || 1
  return [tx / length, ty / length, tz / length]
}

function readPlacedGeometry(api, modelId, placed) {
  const geometry = api.GetGeometry(modelId, placed.geometryExpressID)
  try {
    const vertices = api.GetVertexArray(geometry.GetVertexData(), geometry.GetVertexDataSize())
    const indices = api.GetIndexArray(geometry.GetIndexData(), geometry.GetIndexDataSize())
    const matrix = placed.flatTransformation
    const positions = []
    const normals = []
    for (let index = 0; index < vertices.length; index += 6) {
      positions.push(...transformPoint(matrix, vertices[index], vertices[index + 1], vertices[index + 2]))
      normals.push(...transformNormal(matrix, vertices[index + 3], vertices[index + 4], vertices[index + 5]))
    }
    if (!indices.length) return null
    return {
      colour: toHex(placed.color),
      positions: new Float32Array(positions),
      normals: new Float32Array(normals),
      indices: new Uint32Array(indices),
      sourceTransform: [...matrix],
    }
  } finally {
    geometry.delete()
  }
}

function readGeometry(api, modelId, onProgress) {
  const packets = new Map()
  api.StreamAllMeshes(modelId, (mesh, index, total) => {
    const entityPackets = vectorValues(mesh.geometries)
      .map(placed => readPlacedGeometry(api, modelId, placed))
      .filter(Boolean)
    if (entityPackets.length) packets.set(mesh.expressID, entityPackets)
    if (onProgress && (index % 25 === 0 || index === total - 1)) onProgress(index + 1, total)
  })
  return packets
}

function scalarRecord(api, property, quantityKind = null) {
  const valueHolder = quantityKind ? property[quantityKind] : property.NominalValue
  const value = wrappedValue(valueHolder)
  if (value !== null && typeof value === 'object') return null
  const valueTypeCode = valueHolder?.type
  return {
    name: text(property.Name),
    value,
    valueType: typeName(api, valueTypeCode) || typeof value,
    unit: property.Unit ? wrappedValue(property.Unit) : null,
    quantityKind,
    sourceExpressId: property.expressID ?? null,
  }
}

function readDefinition(api, modelId, definitionId, ownership) {
  const definition = api.GetLine(modelId, definitionId, true)
  const values = []
  for (const property of definition.HasProperties || []) {
    const record = scalarRecord(api, property)
    if (record?.name) values.push(record)
  }
  for (const quantity of definition.Quantities || []) {
    const key = QUANTITY_KEYS.find(candidate => quantity[candidate] != null)
    const record = key ? scalarRecord(api, quantity, key) : null
    if (record?.name) values.push(record)
  }
  values.sort((left, right) => left.name.localeCompare(right.name))
  return {
    name: text(definition.Name) || `Set ${definitionId}`,
    ifcType: ifcClassName(typeName(api, definition.type)),
    ifcTypeName: typeName(api, definition.type),
    expressId: definitionId,
    ownership,
    values,
  }
}

function collectMaterialNames(node, materialType, output, depth = 0) {
  if (!node || typeof node !== 'object' || depth > 8) return
  if (Array.isArray(node)) {
    for (const child of node) collectMaterialNames(child, materialType, output, depth + 1)
    return
  }
  if (node.type === materialType) {
    const name = text(node.Name)
    if (name) output.add(name)
  }
  for (const [key, child] of Object.entries(node)) {
    if (key !== 'expressID' && key !== 'type') collectMaterialNames(child, materialType, output, depth + 1)
  }
}

function eachLineOfType(api, modelId, typeCode, callback) {
  if (typeCode == null) return
  for (const id of vectorValues(api.GetLineIDsWithType(modelId, typeCode))) callback(id)
}

function readFacts(api, WebIFC, modelId) {
  const byEntity = new Map()
  const entry = id => {
    if (!byEntity.has(id)) byEntity.set(id, { propertySets: [], materials: [], typeExpressIds: [] })
    return byEntity.get(id)
  }
  const definitions = new Map()
  const definition = (id, ownership) => {
    const key = `${id}:${ownership}`
    if (!definitions.has(key)) definitions.set(key, readDefinition(api, modelId, id, ownership))
    return definitions.get(key)
  }

  eachLineOfType(api, modelId, WebIFC.IFCRELDEFINESBYPROPERTIES, relationId => {
    const relation = api.GetLine(modelId, relationId)
    const definitionId = relation.RelatingPropertyDefinition?.value
    if (!definitionId) return
    for (const object of relation.RelatedObjects || []) {
      entry(object.value).propertySets.push(definition(definitionId, 'occurrence'))
    }
  })

  eachLineOfType(api, modelId, WebIFC.IFCRELASSOCIATESMATERIAL, relationId => {
    const relation = api.GetLine(modelId, relationId, true)
    const names = new Set()
    collectMaterialNames(relation.RelatingMaterial, WebIFC.IFCMATERIAL, names)
    for (const object of relation.RelatedObjects || []) {
      const target = entry(object.expressID ?? object.value)
      for (const name of names) {
        if (!target.materials.some(material => material.name === name)) {
          target.materials.push({ name, sourceRelationExpressId: relationId, ownership: 'occurrence' })
        }
      }
    }
  })

  eachLineOfType(api, modelId, WebIFC.IFCRELDEFINESBYTYPE, relationId => {
    const relation = api.GetLine(modelId, relationId)
    const typeId = relation.RelatingType?.value
    if (!typeId) return
    const typeObject = api.GetLine(modelId, typeId)
    const inheritedSets = (typeObject.HasPropertySets || [])
      .map(reference => definition(reference.value, 'type'))
    const typeFacts = byEntity.get(typeId)
    for (const object of relation.RelatedObjects || []) {
      const target = entry(object.value)
      target.typeExpressIds.push(typeId)
      target.propertySets.push(...inheritedSets)
      if (!target.materials.length && typeFacts) {
        target.materials.push(...typeFacts.materials.map(material => ({ ...material, ownership: 'type' })))
      }
    }
  })

  for (const facts of byEntity.values()) {
    facts.propertySets.sort((left, right) => left.name.localeCompare(right.name)
      || left.ownership.localeCompare(right.ownership) || left.expressId - right.expressId)
    facts.materials.sort((left, right) => left.name.localeCompare(right.name))
    facts.typeExpressIds.sort((left, right) => left - right)
  }
  return byEntity
}

function referenceIds(value, output = []) {
  if (value == null) return output
  if (Array.isArray(value)) {
    for (const item of value) referenceIds(item, output)
  } else if (typeof value === 'object') {
    const id = value.expressID ?? value.value
    if (Number.isInteger(id)) output.push(id)
  }
  return output
}

function readAllLines(api, modelId) {
  return vectorValues(api.GetAllLines(modelId)).map(expressId => {
    const code = api.GetLineType(modelId, expressId)
    return { expressId, typeCode: code, upperType: typeName(api, code), line: api.GetLine(modelId, expressId) }
  })
}

function relationshipRecord(lineInfo, source, keyForExpress) {
  const relating = []
  const related = []
  for (const [role, value] of Object.entries(lineInfo.line)) {
    const target = role.startsWith('Relating') ? relating : role.startsWith('Related') ? related : null
    if (!target) continue
    for (const expressId of referenceIds(value)) target.push({ role, expressId, sourceKey: keyForExpress(expressId) })
  }
  relating.sort((left, right) => left.role.localeCompare(right.role) || left.expressId - right.expressId)
  related.sort((left, right) => left.role.localeCompare(right.role) || left.expressId - right.expressId)
  return {
    sourceKey: sourceKeyFor(source, lineInfo.expressId, text(lineInfo.line.GlobalId)),
    expressId: lineInfo.expressId,
    globalId: text(lineInfo.line.GlobalId) || null,
    ifcType: ifcClassName(lineInfo.upperType),
    ifcTypeName: lineInfo.upperType,
    name: text(lineInfo.line.Name) || null,
    relating,
    related,
    truthClass: 'source-native',
  }
}

function isEntity(lineInfo, candidateIds) {
  if (!lineInfo.line || lineInfo.upperType.startsWith('IFCREL')) return false
  if (/^IFC(PROPERTYSET|ELEMENTQUANTITY|PROPERTY|QUANTITY|MATERIAL)/.test(lineInfo.upperType)) return false
  return candidateIds.has(lineInfo.expressId) || Boolean(text(lineInfo.line.GlobalId))
}

function declaredUnits(api, WebIFC, modelId) {
  const projectIds = vectorValues(api.GetLineIDsWithType(modelId, WebIFC.IFCPROJECT))
  if (!projectIds.length) return []
  const project = api.GetLine(modelId, projectIds[0], true)
  return (project.UnitsInContext?.Units || []).map(unit => ({
    ifcType: ifcClassName(typeName(api, unit.type)),
    unitType: wrappedValue(unit.UnitType),
    name: wrappedValue(unit.Name),
    prefix: wrappedValue(unit.Prefix),
  }))
}

export function parseIfc(api, WebIFC, bytes, options = {}) {
  const source = validateSource(options)
  const modelId = api.OpenModel(bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes), {
    COORDINATE_TO_ORIGIN: true,
  })
  try {
    const lines = readAllLines(api, modelId)
    const relationshipLines = lines.filter(info => info.upperType.startsWith('IFCREL'))
    const candidateIds = new Set()
    for (const info of relationshipLines) {
      for (const [role, value] of Object.entries(info.line)) {
        if (role.startsWith('Relating') || role.startsWith('Related')) {
          for (const expressId of referenceIds(value)) candidateIds.add(expressId)
        }
      }
    }
    for (const expressId of vectorValues(api.GetLineIDsWithType(modelId, WebIFC.IFCPROJECT))) candidateIds.add(expressId)
    const globalIdCounts = new Map()
    const entityLines = lines.filter(info => isEntity(info, candidateIds))
    for (const info of entityLines) {
      const id = text(info.line.GlobalId)
      if (!isValidIfcGlobalId(id)) continue
      globalIdCounts.set(id, (globalIdCounts.get(id) || 0) + 1)
    }
    const duplicateGlobalIds = new Set([...globalIdCounts].filter(([, count]) => count > 1).map(([id]) => id))
    const lineById = new Map(lines.map(info => [info.expressId, info]))
    const keyForExpress = expressId => {
      const info = lineById.get(expressId)
      return sourceKeyFor(source, expressId, info ? text(info.line.GlobalId) : '', duplicateGlobalIds)
    }
    const facts = readFacts(api, WebIFC, modelId)
    const geometryByEntity = readGeometry(api, modelId, options.onProgress)
    const geometryPackets = [...geometryByEntity].flatMap(([expressId, packets]) => packets.map((packet, packetIndex) => ({
      packetId: `${keyForExpress(expressId)}:geometry:${packetIndex}`,
      entityKey: keyForExpress(expressId),
      expressId,
      colour: packet.colour,
      positions: packet.positions,
      normals: packet.normals,
      indices: packet.indices,
      sourceTransform: packet.sourceTransform,
      transform: [1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1],
      coordinateFrame: 'web-ifc-world-metre-y-up',
    }))).sort((left, right) => left.expressId - right.expressId || left.packetId.localeCompare(right.packetId))

    const entities = entityLines.map(info => {
      const entityFacts = facts.get(info.expressId) || { propertySets: [], materials: [], typeExpressIds: [] }
      const geometry = geometryByEntity.get(info.expressId) || []
      const globalId = text(info.line.GlobalId) || null
      return {
        sourceKey: keyForExpress(info.expressId),
        expressId: info.expressId,
        globalId,
        identityScope: isValidIfcGlobalId(globalId) && !duplicateGlobalIds.has(globalId) ? 'binding-global-id' : 'asset-express-id',
        ifcType: ifcClassName(info.upperType),
        ifcTypeName: info.upperType,
        name: text(info.line.Name) || null,
        longName: text(info.line.LongName) || null,
        objectType: text(info.line.ObjectType) || null,
        predefinedType: wrappedValue(info.line.PredefinedType),
        propertySets: entityFacts.propertySets,
        materials: entityFacts.materials,
        typeExpressIds: entityFacts.typeExpressIds,
        geometryPacketIds: geometry.map((_packet, packetIndex) => `${keyForExpress(info.expressId)}:geometry:${packetIndex}`),
      }
    }).sort((left, right) => left.expressId - right.expressId)

    const relationships = relationshipLines
      .map(info => relationshipRecord(info, source, keyForExpress))
      .sort((left, right) => left.expressId - right.expressId)

    const diagnostics = []
    for (const id of duplicateGlobalIds) diagnostics.push({ level: 'warning', code: 'duplicate-global-id', globalId: id })
    for (const entity of entities) {
      if (!entity.globalId) diagnostics.push({ level: 'warning', code: 'missing-global-id', expressId: entity.expressId })
      else if (!isValidIfcGlobalId(entity.globalId)) diagnostics.push({ level: 'warning', code: 'malformed-global-id', expressId: entity.expressId, globalId: entity.globalId })
    }
    return {
      schemaVersion: 'openbim-kernel-result-v1',
      kernel: { name: '@onuresen/openbim-core', version: OPENBIM_CORE_VERSION },
      source: {
        ...source,
        ifcSchema: String(api.GetModelSchema?.(modelId) || ''),
        parser: { name: 'web-ifc', version: options.parserVersion || 'unknown' },
      },
      coordinateFrame: {
        geometry: 'web-ifc-world-metre-y-up',
        lengthUnit: 'metre',
        coordinateToOrigin: true,
        declaredUnits: declaredUnits(api, WebIFC, modelId),
      },
      entities,
      relationships,
      geometryPackets,
      diagnostics,
    }
  } finally {
    api.CloseModel(modelId)
  }
}
