export async function sha256Digest(bytes) {
  const view = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes)
  if (!globalThis.crypto?.subtle) throw new Error('Web Crypto SHA-256 is unavailable')
  const digest = await globalThis.crypto.subtle.digest('SHA-256', view)
  const hex = [...new Uint8Array(digest)].map(value => value.toString(16).padStart(2, '0')).join('')
  return `sha256:${hex}`
}
