import { sha256Digest } from './digest.js'
import { parseIfc } from './parse-ifc.js'

export function collectTransferables(result) {
  return result.geometryPackets.flatMap(packet => [
    packet.positions.buffer,
    packet.normals.buffer,
    packet.indices.buffer,
  ])
}

export function createIfcWorkerHandler({ loadApi, WebIFC }) {
  if (typeof loadApi !== 'function' || !WebIFC) throw new Error('Worker handler requires loadApi and WebIFC')
  let apiPromise
  return async function handleIfcWorkerMessage(request, emitProgress = () => {}) {
    if (request?.type !== 'parse-ifc' || !(request.bytes instanceof ArrayBuffer)) {
      throw new Error('Invalid OpenBIM Core worker request')
    }
    apiPromise ||= Promise.resolve(loadApi())
    const api = await apiPromise
    const bytes = new Uint8Array(request.bytes)
    const contentDigest = request.source?.contentDigest || await sha256Digest(bytes)
    const result = parseIfc(api, WebIFC, bytes, {
      ...request.source,
      contentDigest,
      parserVersion: request.parserVersion,
      onProgress: (done, total) => emitProgress({ type: 'progress', done, total }),
    })
    return {
      message: { type: 'result', result },
      transfer: collectTransferables(result),
    }
  }
}
