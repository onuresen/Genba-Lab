const SAFE_BINDING = /^[a-z0-9][a-z0-9_-]{0,79}$/
const SHA256 = /^sha256:[0-9a-f]{64}$/
const IFC_GLOBAL_ID = /^[0-9A-Za-z_$]{22}$/

export function isValidIfcGlobalId(value) {
  return IFC_GLOBAL_ID.test(String(value || '').trim())
}

export function validateSource(source) {
  if (!source || typeof source !== 'object') throw new Error('IFC source metadata is required')
  const bindingId = String(source.bindingId || '').trim()
  const assetRef = String(source.assetRef || '').trim()
  const contentDigest = String(source.contentDigest || '').trim().toLowerCase()
  if (!SAFE_BINDING.test(bindingId)) throw new Error('Invalid IFC bindingId')
  if (!assetRef || /^[A-Za-z]:/.test(assetRef) || /^[/\\]/.test(assetRef)
      || /(^|[/\\])\.\.([/\\]|$)/.test(assetRef) || !/\.ifc$/i.test(assetRef)) {
    throw new Error('IFC assetRef must be a project-relative .ifc path')
  }
  if (!SHA256.test(contentDigest)) throw new Error('IFC contentDigest must be sha256:<64 lowercase hex>')
  return Object.freeze({ bindingId, assetRef, contentDigest })
}

export function sourceKeyFor({ bindingId, contentDigest }, expressId, globalId, duplicateGlobalIds = new Set()) {
  const cleanGuid = String(globalId || '').trim()
  if (isValidIfcGlobalId(cleanGuid) && !duplicateGlobalIds.has(cleanGuid)) {
    return `ifc:${bindingId}:guid:${cleanGuid}`
  }
  const digest = contentDigest.slice('sha256:'.length, 'sha256:'.length + 16)
  return `ifc:${bindingId}:asset:${digest}:express:${expressId}`
}
