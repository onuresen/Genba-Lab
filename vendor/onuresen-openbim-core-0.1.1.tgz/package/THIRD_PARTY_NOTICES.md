# Third-party notices

OpenBIM Core uses [`web-ifc`](https://github.com/ThatOpen/engine_web-ifc)
version 0.0.78 as a peer and development dependency. `web-ifc` is distributed
under the Mozilla Public License 2.0. Its JavaScript/WASM artifacts are not
committed in this repository; consumers install or bundle the pinned upstream
package and must retain its applicable license notices.
